//
//  "Evaluate.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface Evaluate
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* evaluate;//评价 
@property(nonatomic, assign) double score;//评分 
@property(nonatomic, strong) BaseEnum* category;//评论分类 

@end
