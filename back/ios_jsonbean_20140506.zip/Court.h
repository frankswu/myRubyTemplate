//
//  "Court.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface Court
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* address;//场地地址 
@property(nonatomic, copy) NSString* phone;//联系电话 
@property(nonatomic, copy) NSString* startTime;//开始时间 
@property(nonatomic, copy) NSString* endTime;//结束时间 
@property(nonatomic, copy) NSString* fee;//收费标准 
@property(nonatomic, copy) NSString* courtDesc;//场地情况 
@property(nonatomic, copy) NSString* courtCount;//场地片数 
@property(nonatomic, copy) NSString* weights;//权重 
@property(nonatomic, assign) double longitude;//经度 
@property(nonatomic, assign) double latitude;//纬度 
@property(nonatomic, strong) BaseCity* city;//城市id 
@property(nonatomic, strong) BaseCity* district;//区县id 

@end
