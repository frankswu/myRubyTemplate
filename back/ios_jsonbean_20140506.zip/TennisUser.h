//
//  "TennisUser.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface TennisUser
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* account;//帐户 
@property(nonatomic, copy) NSString* name;//姓名 
@property(nonatomic, copy) NSString* roles;//角色 
@property(nonatomic, copy) NSString* registerDate;//注册时间 
@property(nonatomic, copy) NSString* address;//地址 
@property(nonatomic, strong) BaseEnum* gender;//性别 0代表男士 1代表女士 
@property(nonatomic, copy) NSString* phote;//头像 
@property(nonatomic, copy) NSString* phone;//联系电话 
@property(nonatomic, strong) BaseEnum* state;//登陆状态 0 在线 1 不在线 2 黑名单 
@property(nonatomic, copy) NSString* integral;//积分 
@property(nonatomic, copy) NSString* accountLevel;//等级 

@end
