//
//  "BaseCity.h"
//  
//
//  Created by gen code
//

#import "BaseCity.h"


@implementation BaseCity



@end
