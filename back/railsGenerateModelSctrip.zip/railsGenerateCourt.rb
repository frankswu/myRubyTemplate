
rails generate model court id:integer address:string phone:string start_time:string end_time:string fee:string court_desc:string court_count:string weights:string longitude:double latitude:double city_id:integer district_id:integer 

