
rails generate model base_city id:integer city_name:string city_type:string 

