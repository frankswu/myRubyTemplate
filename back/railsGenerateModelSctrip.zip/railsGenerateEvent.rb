
rails generate model event id:integer title:string descrition:string phone:string totol_price:double require:string commit_time:timestamp event_time:timestamp address:string longitude:double latitude:double remark:string weight:integer category_id:integer statues_id:integer start_users:list<tmtennisuser> owners:list<tmtennisuser> participant:list<tmtennisuser> evaluates:list<tmevaluate> courts:list<tmcourt> 

