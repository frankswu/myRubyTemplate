
rails generate model evaluate id:integer evaluate:string score:double category_id:integer 

