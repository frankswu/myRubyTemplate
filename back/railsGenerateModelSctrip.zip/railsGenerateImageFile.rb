
rails generate model image_file id:integer file_name:string file_url:string 

