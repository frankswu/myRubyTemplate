
rails generate model tennis_user id:integer account:string name:string password:string roles:string register_date:timestamp age:integer address:string birthday:string gender_id:integer phote:string phone:string email:string tennis_age:integer tennis_level:integer personal_info:integer login_times:integer last_login_date:string device_flag:string state_id:integer integral:string account_level:string friends_impression:list<tmevaluate> image:list<tmimage> 

