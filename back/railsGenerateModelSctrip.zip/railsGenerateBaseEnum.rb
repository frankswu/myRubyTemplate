
rails generate model base_enum id:integer enum_type:string enum_value:string enum_desc:string 

