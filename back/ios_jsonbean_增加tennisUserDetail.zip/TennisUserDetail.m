//
//  "TennisUserDetail.h"
//  
//
//  Created by gen code
//

#import "TennisUserDetail.h"


@implementation TennisUserDetail



@end
