//
//  "BaseEnum.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface BaseEnum
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* enumType;//基础枚举类型 
@property(nonatomic, copy) NSString* enumValue;//枚举值 
@property(nonatomic, copy) NSString* enumDesc;//枚举值描述 

@end
