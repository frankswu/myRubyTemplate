//
//  "Event.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface Event
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* title;//标题 
@property(nonatomic, copy) NSString* descrition;//内容描述 
@property(nonatomic, copy) NSString* phone;//电话 
@property(nonatomic, assign) double totolPrice;//费用 
@property(nonatomic, copy) NSString* require;//对手水平要求 
@property(nonatomic, strong) NSDate* commitTime;//发起时间 
@property(nonatomic, strong) NSDate* eventTime;//活动时间 
@property(nonatomic, copy) NSString* address;//地点 
@property(nonatomic, assign) double longitude;//经度 
@property(nonatomic, assign) double latitude;//纬度 
@property(nonatomic, copy) NSString* remark;//备注 
@property(nonatomic, assign) int weight;//权重 
@property(nonatomic, strong) BaseEnum* category;//分类 
@property(nonatomic, strong) BaseEnum* statues;//状态：2审核中，1未完成，0已完成 
@property(nonatomic, strong) List<TennisUser>* startUsers_TennisUser_List;//收藏 
@property(nonatomic, strong) List<TennisUser>* owners_TennisUser_List;// // 发起者 
@property(nonatomic, strong) List<TennisUser>* participant_TennisUser_List;// // 参与者 
@property(nonatomic, strong) List<Evaluate>* comments_Evaluate_List;//评论 
@property(nonatomic, strong) List<Court>* courts_Court_List;//场地 

@end
