//
//  "TennisUserDetail.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface TennisUserDetail
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* account;//帐户 
@property(nonatomic, copy) NSString* name;//姓名 
@property(nonatomic, copy) NSString* password;//密码 
@property(nonatomic, copy) NSString* roles;//角色 
@property(nonatomic, copy) NSString* registerDate;//注册时间 
@property(nonatomic, assign) int age;//年龄 
@property(nonatomic, copy) NSString* address;//地址 
@property(nonatomic, copy) NSString* birthday;//生日 用时间戳？（简单的使用格式化的日期字符串也可以） 
@property(nonatomic, copy) NSString* phote;//头像 
@property(nonatomic, copy) NSString* phone;//联系电话 
@property(nonatomic, copy) NSString* email;//邮箱 
@property(nonatomic, assign) int tennisAge;//球龄 
@property(nonatomic, assign) int tennisLevel;//水平 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 
@property(nonatomic, assign) int personalInfo;//个人说明 
@property(nonatomic, assign) int loginTimes;//登陆次数 
@property(nonatomic, copy) NSString* lastLoginDate;//最后登陆时间 
@property(nonatomic, copy) NSString* deviceFlag;//设备标识 
@property(nonatomic, copy) NSString* integral;//积分 
@property(nonatomic, copy) NSString* accountLevel;//等级 
@property(nonatomic, strong) BaseEnum* gender_BaseEnum_Model;//性别 0代表男士 1代表女士 
@property(nonatomic, strong) BaseEnum* state_BaseEnum_Model;//登陆状态 0 在线 1 不在线 2 黑名单 
@property(nonatomic, strong) NSMutableArray* friends_Evaluate_List;//好友印象 
@property(nonatomic, strong) NSMutableArray* image_Image_List;//照片 

@end
