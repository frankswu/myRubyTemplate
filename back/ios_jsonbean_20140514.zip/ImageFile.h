//
//  "ImageFile.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface ImageFile
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* fileName;//文件名称 
@property(nonatomic, copy) NSString* fileUrl;//文件url 

@end
