//
//  "BaseCity.h"
//  
//
//  Created by gen code
//



#import <Foundation/Foundation.h>

@interface BaseCity
	
@property(nonatomic, assign) long long id;// 
@property(nonatomic, copy) NSString* cityName;//城市名称 
@property(nonatomic, copy) NSString* cityType;//城市类型 

@end
