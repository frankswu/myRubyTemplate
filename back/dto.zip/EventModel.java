package org.springside.examples.quickstart.test;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author gen code for bean
 *
 */
@Entity
@Table(name = "tb_event")
public class Event extends IdEntity {
	
    /**  */
    private long id;
    /** 标题 */
    private String title;
    /** 内容描述 */
    private String descrition;
    /** 电话 */
    private String phone;
    /** 费用 */
    private double totolPrice;
    /** 对手水平要求 */
    private String require;
    /** 发起时间 */
    private Date commitTime;
    /** 活动时间 */
    private Date eventTime;
    /** 地点 */
    private String address;
    /** 经度 */
    private double longitude;
    /** 纬度 */
    private double latitude;
    /** 备注 */
    private String remark;
    /** 权重 */
    private int weight;
    /** 分类 */
    private BaseEnum category;
    /** 状态：2审核中，1未完成，0已完成 */
    private BaseEnum statues;
    /** 收藏 */
    private List<TennisUser> startUsers = Lists.newArrayList();
    /**  // 发起者 */
    private List<TennisUser> owners = Lists.newArrayList();
    /**  // 参与者 */
    private List<TennisUser> participant = Lists.newArrayList();
    /** 评论 */
    private List<Evaluate> evaluates = Lists.newArrayList();
    /** 场地 */
    private List<TMCourt> courts = Lists.newArrayList();

	
    /** get  */
    public long getId(){
    	return this.id;
    }

    /** set  */
    public void setId(long id){
    	this.id = id;
    }
    
    /** get 标题 */
    public String getTitle(){
    	return this.title;
    }

    /** set 标题 */
    public void setTitle(String title){
    	this.title = title;
    }
    
    /** get 内容描述 */
    public String getDescrition(){
    	return this.descrition;
    }

    /** set 内容描述 */
    public void setDescrition(String descrition){
    	this.descrition = descrition;
    }
    
    /** get 电话 */
    public String getPhone(){
    	return this.phone;
    }

    /** set 电话 */
    public void setPhone(String phone){
    	this.phone = phone;
    }
    
    /** get 费用 */
    public double getTotolPrice(){
    	return this.totolPrice;
    }

    /** set 费用 */
    public void setTotolPrice(double totolPrice){
    	this.totolPrice = totolPrice;
    }
    
    /** get 对手水平要求 */
    public String getRequire(){
    	return this.require;
    }

    /** set 对手水平要求 */
    public void setRequire(String require){
    	this.require = require;
    }
    
    /** get 发起时间 */
    public Date getCommitTime(){
    	return this.commitTime;
    }

    /** set 发起时间 */
    public void setCommitTime(Date commitTime){
    	this.commitTime = commitTime;
    }
    
    /** get 活动时间 */
    public Date getEventTime(){
    	return this.eventTime;
    }

    /** set 活动时间 */
    public void setEventTime(Date eventTime){
    	this.eventTime = eventTime;
    }
    
    /** get 地点 */
    public String getAddress(){
    	return this.address;
    }

    /** set 地点 */
    public void setAddress(String address){
    	this.address = address;
    }
    
    /** get 经度 */
    public double getLongitude(){
    	return this.longitude;
    }

    /** set 经度 */
    public void setLongitude(double longitude){
    	this.longitude = longitude;
    }
    
    /** get 纬度 */
    public double getLatitude(){
    	return this.latitude;
    }

    /** set 纬度 */
    public void setLatitude(double latitude){
    	this.latitude = latitude;
    }
    
    /** get 备注 */
    public String getRemark(){
    	return this.remark;
    }

    /** set 备注 */
    public void setRemark(String remark){
    	this.remark = remark;
    }
    
    /** get 权重 */
    public int getWeight(){
    	return this.weight;
    }

    /** set 权重 */
    public void setWeight(int weight){
    	this.weight = weight;
    }
    
    /** get 分类 */
	@NotNull
	@OneToOne
	@JoinColumn(name = "category_id")
    public BaseEnum getCategory(){
    	return this.category;
    }

    /** set 分类 */
    public void setCategory(BaseEnum category){
    	this.category = category;
    }
    
    /** get 状态：2审核中，1未完成，0已完成 */
	@NotNull
	@OneToOne
	@JoinColumn(name = "statues_id")
    public BaseEnum getStatues(){
    	return this.statues;
    }

    /** set 状态：2审核中，1未完成，0已完成 */
    public void setStatues(BaseEnum statues){
    	this.statues = statues;
    }
    
    /** get 收藏 */
	@Transient
	public List<EventDTO> getStartUsersList() {
		List<EventDTO> eventDTOList = BeanMapper.mapList(startUsers, EventDTO.class);
		return eventDTOList;
	}

	@ManyToMany
	@JoinTable(name = "tb_event_startusers", joinColumns = { @JoinColumn(name = "event_id") }, inverseJoinColumns = { @JoinColumn(name = "startusers_id") })
	@Fetch(value = FetchMode.SUBSELECT)
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	@JsonIgnore
    public List<TennisUser> getStartUsers(){
    	return this.startUsers;
    }

    /** set 收藏 */
    public void setStartUsers(List<TennisUser> startUsers){
    	this.startUsers = startUsers;
    }
    
    /** get  // 发起者 */
	@Transient
	public List<EventDTO> getOwnersList() {
		List<EventDTO> eventDTOList = BeanMapper.mapList(owners, EventDTO.class);
		return eventDTOList;
	}

	@ManyToMany
	@JoinTable(name = "tb_event_owners", joinColumns = { @JoinColumn(name = "event_id") }, inverseJoinColumns = { @JoinColumn(name = "owners_id") })
	@Fetch(value = FetchMode.SUBSELECT)
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	@JsonIgnore
    public List<TennisUser> getOwners(){
    	return this.owners;
    }

    /** set  // 发起者 */
    public void setOwners(List<TennisUser> owners){
    	this.owners = owners;
    }
    
    /** get  // 参与者 */
	@Transient
	public List<EventDTO> getParticipantList() {
		List<EventDTO> eventDTOList = BeanMapper.mapList(participant, EventDTO.class);
		return eventDTOList;
	}

	@ManyToMany
	@JoinTable(name = "tb_event_participant", joinColumns = { @JoinColumn(name = "event_id") }, inverseJoinColumns = { @JoinColumn(name = "participant_id") })
	@Fetch(value = FetchMode.SUBSELECT)
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	@JsonIgnore
    public List<TennisUser> getParticipant(){
    	return this.participant;
    }

    /** set  // 参与者 */
    public void setParticipant(List<TennisUser> participant){
    	this.participant = participant;
    }
    
    /** get 评论 */
	@Transient
	public List<EventDTO> getEvaluatesList() {
		List<EventDTO> eventDTOList = BeanMapper.mapList(evaluates, EventDTO.class);
		return eventDTOList;
	}

	@ManyToMany
	@JoinTable(name = "tb_event_evaluates", joinColumns = { @JoinColumn(name = "event_id") }, inverseJoinColumns = { @JoinColumn(name = "evaluates_id") })
	@Fetch(value = FetchMode.SUBSELECT)
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	@JsonIgnore
    public List<Evaluate> getEvaluates(){
    	return this.evaluates;
    }

    /** set 评论 */
    public void setEvaluates(List<Evaluate> evaluates){
    	this.evaluates = evaluates;
    }
    
    /** get 场地 */
	@Transient
	public List<EventDTO> getCourtsList() {
		List<EventDTO> eventDTOList = BeanMapper.mapList(courts, EventDTO.class);
		return eventDTOList;
	}

	@ManyToMany
	@JoinTable(name = "tb_event_courts", joinColumns = { @JoinColumn(name = "event_id") }, inverseJoinColumns = { @JoinColumn(name = "courts_id") })
	@Fetch(value = FetchMode.SUBSELECT)
	@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
	@JsonIgnore
    public List<TMCourt> getCourts(){
    	return this.courts;
    }

    /** set 场地 */
    public void setCourts(List<TMCourt> courts){
    	this.courts = courts;
    }
    

}
