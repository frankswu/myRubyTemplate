
package org.springside.examples.quickstart.restdto;

import java.util.Date;
import org.springside.examples.quickstart.entity.TMBaseEnum;
import org.springside.modules.utils.Collections3;
import org.springside.modules.mapper.BeanMapper;



public class EventDTO {

	
    /**  */
    private long id;
    /** 标题 */
    private String title;
    /** 内容描述 */
    private String descrition;
    /** 电话 */
    private String phone;
    /** 费用 */
    private double totolPrice;
    /** 对手水平要求 */
    private String require;
    /** 发起时间 */
    private String commitTime;
    /** 活动时间 */
    private String eventTime;
    /** 地点 */
    private String address;
    /** 经度 */
    private double longitude;
    /** 纬度 */
    private double latitude;
    /** 备注 */
    private String remark;
    /** 权重 */
    private int weight;
    /** 分类 */
    private BaseEnum categoryModel;
    /** 状态：2审核中，1未完成，0已完成 */
    private BaseEnum statuesModel;
    /** 收藏 */
    private List<TennisUser> startUsersModelList;
    /**  // 发起者 */
    private List<TennisUser> ownersModelList;
    /**  // 参与者 */
    private List<TennisUser> participantModelList;
    /** 评论 */
    private List<Evaluate> evaluatesModelList;
    /** 场地 */
    private List<TMCourt> courtsModelList;


	
    /** get  */
    public long getId(){
    	return this.id;
    }

    /** set  */
    public void setId(long id){
    	this.id = id;
    }
    
    /** get 标题 */
    public String getTitle(){
    	return this.title;
    }

    /** set 标题 */
    public void setTitle(String title){
    	this.title = title;
    }
    
    /** get 内容描述 */
    public String getDescrition(){
    	return this.descrition;
    }

    /** set 内容描述 */
    public void setDescrition(String descrition){
    	this.descrition = descrition;
    }
    
    /** get 电话 */
    public String getPhone(){
    	return this.phone;
    }

    /** set 电话 */
    public void setPhone(String phone){
    	this.phone = phone;
    }
    
    /** get 费用 */
    public double getTotolPrice(){
    	return this.totolPrice;
    }

    /** set 费用 */
    public void setTotolPrice(double totolPrice){
    	this.totolPrice = totolPrice;
    }
    
    /** get 对手水平要求 */
    public String getRequire(){
    	return this.require;
    }

    /** set 对手水平要求 */
    public void setRequire(String require){
    	this.require = require;
    }
    
    /** get 发起时间 */
    public String getCommitTime(){
    	return this.commitTime;
    }

    /** set 发起时间 */
    public void setCommitTime(String commitTime){
    	this.commitTime = commitTime;
    }
    
    /** get 活动时间 */
    public String getEventTime(){
    	return this.eventTime;
    }

    /** set 活动时间 */
    public void setEventTime(String eventTime){
    	this.eventTime = eventTime;
    }
    
    /** get 地点 */
    public String getAddress(){
    	return this.address;
    }

    /** set 地点 */
    public void setAddress(String address){
    	this.address = address;
    }
    
    /** get 经度 */
    public double getLongitude(){
    	return this.longitude;
    }

    /** set 经度 */
    public void setLongitude(double longitude){
    	this.longitude = longitude;
    }
    
    /** get 纬度 */
    public double getLatitude(){
    	return this.latitude;
    }

    /** set 纬度 */
    public void setLatitude(double latitude){
    	this.latitude = latitude;
    }
    
    /** get 备注 */
    public String getRemark(){
    	return this.remark;
    }

    /** set 备注 */
    public void setRemark(String remark){
    	this.remark = remark;
    }
    
    /** get 权重 */
    public int getWeight(){
    	return this.weight;
    }

    /** set 权重 */
    public void setWeight(int weight){
    	this.weight = weight;
    }
    
    public Long getCategoryModelId(){
    	return this.categoryModel.getId();
    }

    public BaseEnumDTO getCategoryModelDTO(){
    	return BeanMapper.map(this.categoryModel,BaseEnumDTO.class);
    }
    /** get 分类 */
    public BaseEnum getCategoryModel(){
    	return this.categoryModel;
    }

    /** set 分类 */
    public void setCategoryModel(BaseEnum categoryModel){
    	this.categoryModel = categoryModel;
    }
    
    public Long getStatuesModelId(){
    	return this.statuesModel.getId();
    }

    public BaseEnumDTO getStatuesModelDTO(){
    	return BeanMapper.map(this.statuesModel,BaseEnumDTO.class);
    }
    /** get 状态：2审核中，1未完成，0已完成 */
    public BaseEnum getStatuesModel(){
    	return this.statuesModel;
    }

    /** set 状态：2审核中，1未完成，0已完成 */
    public void setStatuesModel(BaseEnum statuesModel){
    	this.statuesModel = statuesModel;
    }
    
    public List<Long> getStartUsersModelListIds(){
    	return BeanMapper.mapList(this.startUsersModelList,"id");
    }

    public List<TennisUserDTO> getStartUsersModelListDTO(){
    	return BeanMapper.mapList(this.startUsersModelList,TennisUserDTO.class);
    }
    /** get 收藏 */
    public List<TennisUser> getStartUsersModelList(){
    	return this.startUsersModelList;
    }

    /** set 收藏 */
    public void setStartUsersModelList(List<TennisUser> startUsersModelList){
    	this.startUsersModelList = startUsersModelList;
    }
    
    public List<Long> getOwnersModelListIds(){
    	return BeanMapper.mapList(this.ownersModelList,"id");
    }

    public List<TennisUserDTO> getOwnersModelListDTO(){
    	return BeanMapper.mapList(this.ownersModelList,TennisUserDTO.class);
    }
    /** get  // 发起者 */
    public List<TennisUser> getOwnersModelList(){
    	return this.ownersModelList;
    }

    /** set  // 发起者 */
    public void setOwnersModelList(List<TennisUser> ownersModelList){
    	this.ownersModelList = ownersModelList;
    }
    
    public List<Long> getParticipantModelListIds(){
    	return BeanMapper.mapList(this.participantModelList,"id");
    }

    public List<TennisUserDTO> getParticipantModelListDTO(){
    	return BeanMapper.mapList(this.participantModelList,TennisUserDTO.class);
    }
    /** get  // 参与者 */
    public List<TennisUser> getParticipantModelList(){
    	return this.participantModelList;
    }

    /** set  // 参与者 */
    public void setParticipantModelList(List<TennisUser> participantModelList){
    	this.participantModelList = participantModelList;
    }
    
    public List<Long> getEvaluatesModelListIds(){
    	return BeanMapper.mapList(this.evaluatesModelList,"id");
    }

    public List<EvaluateDTO> getEvaluatesModelListDTO(){
    	return BeanMapper.mapList(this.evaluatesModelList,EvaluateDTO.class);
    }
    /** get 评论 */
    public List<Evaluate> getEvaluatesModelList(){
    	return this.evaluatesModelList;
    }

    /** set 评论 */
    public void setEvaluatesModelList(List<Evaluate> evaluatesModelList){
    	this.evaluatesModelList = evaluatesModelList;
    }
    
    public List<Long> getCourtsModelListIds(){
    	return BeanMapper.mapList(this.courtsModelList,"id");
    }

    public List<TMCourtDTO> getCourtsModelListDTO(){
    	return BeanMapper.mapList(this.courtsModelList,TMCourtDTO.class);
    }
    /** get 场地 */
    public List<TMCourt> getCourtsModelList(){
    	return this.courtsModelList;
    }

    /** set 场地 */
    public void setCourtsModelList(List<TMCourt> courtsModelList){
    	this.courtsModelList = courtsModelList;
    }
    


}
