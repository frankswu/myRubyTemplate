package org.springside.examples.quickstart.test;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author gen code for bean
 *
 */
@Entity
@Table(name = "tb_imagefile")
public class ImageFile extends IdEntity {
	
    /**  */
    private long id;
    /** 文件名称 */
    private String fileName;
    /** 文件url */
    private String fileUrl;

	
    /** get  */
    public long getId(){
    	return this.id;
    }

    /** set  */
    public void setId(long id){
    	this.id = id;
    }
    
    /** get 文件名称 */
    public String getFileName(){
    	return this.fileName;
    }

    /** set 文件名称 */
    public void setFileName(String fileName){
    	this.fileName = fileName;
    }
    
    /** get 文件url */
    public String getFileUrl(){
    	return this.fileUrl;
    }

    /** set 文件url */
    public void setFileUrl(String fileUrl){
    	this.fileUrl = fileUrl;
    }
    

}
