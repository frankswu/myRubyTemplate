package org.springside.examples.quickstart.test;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author gen code for bean
 *
 */
@Entity
@Table(name = "tb_evaluate")
public class Evaluate extends IdEntity {
	
    /**  */
    private long id;
    /** 评价 */
    private String evaluate;
    /** 评分 */
    private double score;
    /** 评论分类 */
    private BaseEnum category;

	
    /** get  */
    public long getId(){
    	return this.id;
    }

    /** set  */
    public void setId(long id){
    	this.id = id;
    }
    
    /** get 评价 */
    public String getEvaluate(){
    	return this.evaluate;
    }

    /** set 评价 */
    public void setEvaluate(String evaluate){
    	this.evaluate = evaluate;
    }
    
    /** get 评分 */
    public double getScore(){
    	return this.score;
    }

    /** set 评分 */
    public void setScore(double score){
    	this.score = score;
    }
    
    /** get 评论分类 */
	@NotNull
	@OneToOne
	@JoinColumn(name = "category_id")
    public BaseEnum getCategory(){
    	return this.category;
    }

    /** set 评论分类 */
    public void setCategory(BaseEnum category){
    	this.category = category;
    }
    

}
